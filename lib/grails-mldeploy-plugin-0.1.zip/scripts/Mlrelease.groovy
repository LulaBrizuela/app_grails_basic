/**
*  Mercadolibre's New World Deployment Scripts: Release
*    - Only GIT
*
*/


includeTargets << grailsScript("Init")

scriptEnv = Ant.project.properties.'grails.env'

includeTargets << new File("$mldeployPluginPluginDir/scripts/_MLVersioning.groovy")

target(main:"Provides Ground-Zero Deployment utilities") {
	depends(parseArguments)

  	//Display help if it passes the parameter "-h"
  	if( argsMap.h ) {
		printHelp()
		exit(1)
  	}

  	targetLabel = '[DEBUG - New World Versioning]'
  	println ""
  	println "***********************************************************"  
  	println "*      Mercadolibre New World Versioning utilities        *"
  	println "***********************************************************"
  	println ""

  	println "$targetLabel Params: $argsMap"
  
  	println "$targetLabel Custom Environment: $scriptEnv"
  	println "$targetLabel Target Action 'release'"

	/**
	* Release current version and upgrede to a new version
	**/
  	targetLabel = '[DEBUG - Release]'
        println "$targetLabel Starting releasing . . ."

        checkRepositorySynchronizationStatus()
        tagAndCommitTag()
        upgradeVersion()
        commitUpgradedVersion()

        println "$targetLabel Release finished"
}  


target(printHelp:"How to use this plugin") {
  println """
 *****************************      
* New World Versioning Plugin *
 *****************************
> grails mlrelease [VERSION_TYPE] [options]
----------------------------------------

VERSION_TYPE,
    Increases indicated sequence version and updates apps metadata and pom.xml:
      none: overwrites current tag
      major: x+1.y.z
      minor: x.y+1.z
      internal: increase internal version (alpha, beta, release candidate) x.y.z+1
  
options,
  -tagSuffix
    Suffix is added to generate the tag.
  """
}


/*
Code references and examples:
// Retreave build number from JVM parameter: -DbambooBuildNumber=xxx
//  buildNumber = Ant.project.properties.'bambooBuildNumber'  
//  println "$targetLabel Tag build number suffix: $buildNumber"
*/

setDefaultTarget("main")

