//
// This script is executed by Grails when the plugin is uninstalled from project.
//

//ant.rmdir(dir:"${basedir}/scripts/mldeploy")
