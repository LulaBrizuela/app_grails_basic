/**
*  Mercadolibre's New World Versioning Scripts
*  (Only GIT SCM)
*    - default: increment app internal version by 1
*    - minor
*    - major
*
*  - The current appVersion is the tag that has not been deployed. 
*    When it is deployed, the version is upgraded depending on the version scheme specified
*
*  Versionning Scheme (http://en.wikipedia.org/wiki/Software_versioning#Sequence-based_identifiers)
*  Example: app.name-major.minor.release_type
*  Major number is increased when there are significant jumps in functionality. 
*  Minor number is incremented when only minor features or significant fixes have been added.
*  Release type is an alphanumeric string denoting the release type. i.e. "alpha", "beta" or "release candidate". 
*  A release train using this approach might look like 0.5, 0.6, 0.7, 0.8, 0.9 == 1.0b1, 1.0b2 (with some fixes),
*  1.0b3 (with more fixes) == 1.0rc1 (which, if it is stable enough) == 1.0. If 1.0rc1 turns out to have 
*  bugs which must be fixed, it turns into 1.0rc2, and so on.
*/


/**
* It's highly recommended to run every kind of local tests before tagging
* include any necessary targets below
*/
includeTargets << grailsScript("Init")

/*
* MG: 'Tag version following the versionning scheme.'
* Takes the version parameter and increments the version depending on it. 
* If none is specified, the internal release is incremented (i.e.: x.y.(z+1))
*/
target(upgradeVersion: 'Upgrade application version to next version') {
  	def targetLabel = "[DEBUG - Upgrade Version]"
	def appVersion = metadata.'app.version'
	def appName = metadata.'app.name'
	println "$targetLabel Aplication $appName. Current Version $appVersion"

	def targetVersionType = argsMap.params ? argsMap.params[0] : null
	if( argsMap.params.size() >1 ) {
		argsMap.params = argsMap.params[1..-1]
	} else {
		argsMap.params.clear()
	}
	
	//In case 'next' is especified
	currentVersion = appVersion.tokenize('.')
	// Initialize version scheme to major.minor.releaseType
	for ( i in 0..2 ) {
    		currentVersion[i] = currentVersion[i]? currentVersion[i] : '0'
  	}
  
  	println "$targetLabel Increasing sequence: " + (targetVersionType != null ? targetVersionType : "not specified (Internal by default)")
  
  	def versionIndex = null
  	switch(targetVersionType) {
      		case 'major':
        		versionIndex = 0
        		break        
      		case 'minor': 
        		versionIndex = 1
        		break
      		case 'internal':  //releaseType
        		versionIndex = 2
      			break  
      		default: //Overwrite current TAG
        		versionIndex = 2      
        		break
  	}
  
  	if (versionIndex != null) {
    		currentVersion[versionIndex] = currentVersion[versionIndex]? (currentVersion[versionIndex] as int)+ 1 : '1'
  	}

  	def newVersion = currentVersion.join('.')
 	println "$targetLabel New Application Version: $newVersion"

	////Se modifica la version en application.properties
	if (!metadata.'app.version'.equals(newVersion)) {
		metadata.'app.version' = newVersion
		metadata.persist()
	}
	println "$targetLabel application.properties updated: app.version=$newVersion"	

	////Se Modifica la version en pom.xml
	def xmlFile = "pom.xml"
	def xml = new XmlParser().parse(xmlFile)
	def xml_version = xml.version[0]
	xml_version.value = [newVersion]
	new XmlNodePrinter(new PrintWriter(new FileWriter(xmlFile))).print(xml)	
	println "$targetLabel pom.xml updated: version=$newVersion"


	// TODO: Refactorizar para cuando se transforme en plugin
	//event("StatusFinal", [ "Application version updated to $newVersion"])
}



/*
* Is the local repository holding changes that haven't been pushed to remote?
*/
target(checkRepositorySynchronizationStatus: 'Verify that there is no diferences between local and remote repositories') {
  	def targetLabel = "[Check Repo Sync Status]"
  
	//git status
  	println "$targetLabel Checking working directory synchronization status ..."
	exec  resultproperty:'cmdreturn1', outputproperty:'cmdout1', failonerror:false, executable:'git', { arg line:'status'}
	if (ant.project.properties.cmdout1.contains("nothing to commit") || ant.project.properties.cmdout1.contains("nothing added to commit")) {
		println "Working directory Synchronized!"
	} else {
	  	println "Working directory out of Sync: You need to add and/or commit to your Local Repo"
	  	exit(1)
	}	
	  
	//git remote show origin
	println "$targetLabel Checking Server Vs Local repository synchronization status ..."
	exec resultproperty:'cmdreturn2', outputproperty:'cmdout2', failonerror:false, executable:'git', { arg line:'remote show origin'}
	if (ant.project.properties.cmdout2.contains("local out of date")) {
		println "$targetLabel Remote repository changes not pulled yet. Pull needed!" 
		println "$targetLabel (You'll probably need to re-run your tests)"
		exit(1)
	} else if (ant.project.properties.cmdout2.contains("fast-forwardable")) {
	  	println "$targetLabel Local repository changes not pushed yet. Push needed!"
	  	exit(1)
	} else {
	    	println "$targetLabel Local and Remote repositories synchronized!"
	}	  
}



target(tagAndCommitTag: 'Tag this app.version and commit it. Only this tag') {
  	def targetLabel = "[DEBUG - Tag and commit TAG]"
  	def suffix  = null
	if( argsMap.tagSuffix ) {
		suffix = argsMap.params[1] ? argsMap.params[1] : argsMap.params[0]
		if( argsMap.params.size() >1 ) {
			argsMap.params = argsMap.params[1..-1]
		} else {
			argsMap.params.clear()
		}
  	}

 	tag = metadata.'app.version'
  	println "$targetLabel Current App Version = $tag"
  	if (suffix != null && !suffix.isEmpty()) {
    		println "$targetLabel Applying Build Number suffix: $suffix"
   		tag += '.' + suffix
  	} else {
    		println "$targetLabel No Build Number received. App Version metadata will be used as tag: $tag"
  	}
  
	//git tag
  	println "$targetLabel Creating Tag: $tag"
	exec  resultproperty:'cmdreturn_tagAndCommitTag', outputproperty:'cmdout_tagAndCommitTag', failonerror:true, executable:'git', { arg line:'tag' }
	if (ant.project.properties.cmdout_tagAndCommitTag.contains("$tag")) {
		println ""
		println "$targetLabel There is already a Tag nemed: $tag. Tag will be overwritten(forced)!!!"
		println ""
	}

	//git tag $tag
	// If there ara changes since last tag, the tag will be overwrited anyways
	exec executable:"git", {arg line:"tag $tag"}
	println "$targetLabel Tag created: $tag" 
	
	//git push origin $tag
	println "$targetLabel Pushing tag: $tag" 
	exec executable:"git", {arg line:"push origin $tag"}
	println "$targetLabel Tag pusshed: $tag"
}



target(commitUpgradedVersion: 'Commit the Upgraded Version (appVersion) metadata') {
	def targetLabel = "[DEBUG - Push commit ]"
	def appVersion = metadata.'app.version'
	
	//git commit application.properties pom.xml -m 'Version Upgraded my ML Deployment plugin [$appVersion]'
	exec executable:"git", {
		arg line:"commit application.properties pom.xml -m 'Version Upgraded my ML Deployment plugin [$appVersion]'"
	}
	
	//git branch | grep \* | awk '{ print $2}'
	exec  resultproperty:'cmdreturn', outputproperty:'cmdout', failonerror:false, executable:'git', { arg line:"branch" }
	def results = ant.project.properties.cmdout =~ /\* (\w+)/
	def branch_name = results[0][1]
	println "$targetLabel Pushing branch: $branch_name"

	//git push origin
	exec executable:"git", {arg line:"push origin $branch_name"}
}




/*
* MG: Check consistency between current application metadata (application.properties) and 
* repository tags
*/
target(checkExistingCurrentVersionTag: 'Upgrade application version to next version') {
 	def targetLabel = "[Tag validation]"
	def appVersion = metadata.'app.version'
	
	//git tag
	println "$targetLabel Checking current version existing Tag ..."
	exec  resultproperty:'cmdreturn_cecvt', outputproperty:'cmdout_cecvt', failonerror:true, executable:'git', { arg line:'tag'}	     
	if (!ant.project.properties.cmdout_cecvt.contains("$appVersion")) {
		println "$targetLabel There is no Tag for current version: $appVersion. Tag one!"
	  	exit 1
	} else {
	  	println "$targetLabel There is a Tag for current version: $appVersion"
	}
	
}


setDefaultTarget(upgradeVersion)
