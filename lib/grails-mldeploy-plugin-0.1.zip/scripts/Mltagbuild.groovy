/**
*  Mercadolibre's New World Deployment Scripts: Release
*    - Only GIT
*
*/


includeTargets << grailsScript("Init")

scriptEnv = Ant.project.properties.'grails.env'

includeTargets << new File("$mldeployPluginPluginDir/scripts/_MLVersioning.groovy")

target(main:"Provides Ground-Zero Deployment utilities") {
        depends(parseArguments)

        //Display help if it passes the parameter "-h"
        if( argsMap.h ) {
                printHelp()
                exit(1)
        }

        targetLabel = '[DEBUG - New World Versioning]'
        println ""
        println "***********************************************************"
        println "*      Mercadolibre New World Versioning utilities        *"
        println "***********************************************************"
        println ""

        println "$targetLabel Params: $argsMap"

        println "$targetLabel Custom Environment: $scriptEnv"
        println "$targetLabel Target Action 'release'"


	/**
	* Call from bamboo CI
	* ${bamboo.buildNumber} must be passed as argument
	* as System Environment Variables
	*/
	targetLabel = '[DEBUG - Tag Build]'
  	println "$targetLabel Parametes left (should be buildNumber): $argsMap.params"
  	tagAndCommitTag()
}


target(printHelp:"How to use this plugin") {
  println """
 *****************************      
* New World Versioning Plugin *
 *****************************
> grails mltagbuild [options]
----------------------------------------

options,
  -tagSuffix
    Suffix is added to generate the tag.
  """
}

setDefaultTarget("main")

